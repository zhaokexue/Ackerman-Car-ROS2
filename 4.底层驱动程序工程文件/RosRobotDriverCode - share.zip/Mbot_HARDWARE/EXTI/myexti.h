
#ifndef __MYEXTI_H__
#define __MYEXTI_H__	 

#include "stm32f10x.h"

void MBOT_EXTI_Init(void);	//�ⲿ�жϳ�ʼ��	

#endif

